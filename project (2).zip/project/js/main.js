/* app.js - uses modern features required by project */
const temples = [
    { id: 'tokyo', name: 'Tokyo Japan Temple', location: 'Tokyo, Japan', dedicated: '1980-03-17', img: 'images/tokyo.jpg', short: 'A modern temple in Tokyo.' },
    { id: 'saltlake', name: 'Salt Lake Temple', location: 'Salt Lake City, USA', dedicated: '1893-04-06', img: 'images/saltlake.jpg', short: 'Historic temple in Utah.' },
    { id: 'manila', name: 'Manila Temple', location: 'Manila, Philippines', dedicated: '1984-09-25', img: 'images/manila.jpg', short: 'Beautiful temple in Manila.' }
];

// Utility functions
function $(sel) { return document.querySelector(sel) }
function createNode(tag, attrs = {}) {
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
    return el;
}

// show featured card on index
export function showFeatured(random = false) {
    const container = $('#featured-card');
    if (!container) return;
    const item = random ? temples[Math.floor(Math.random() * temples.length)] : temples[0];
    container.innerHTML = `
    <div class="card">
      <h4>${item.name}</h4>
      <img src="${item.img}" alt="${item.name}" loading="lazy" width="600" height="400">
      <p>${item.short}</p>
      <p><strong>Location:</strong> ${item.location}</p>
      <p><strong>Dedicated:</strong> ${item.dedicated}</p>
      <button data-id="${item.id}" class="fav-btn">Save favorite</button>
    </div>
  `;
}

// build temple list (uses template literals exclusively)
export function buildTempleList() {
    const list = $('#temple-list');
    if (!list) return;
    list.innerHTML = temples.map(t => `
    <article class="card">
      <h4>${t.name}</h4>
      <img src="${t.img}" alt="${t.name}" loading="lazy" width="400" height="260">
      <p>${t.short}</p>
      <p><strong>Location:</strong> ${t.location}</p>
      <p><strong>Dedicated:</strong> ${t.dedicated}</p>
      <button data-id="${t.id}" class="fav-btn">Add to favorites</button>
    </article>
  `).join('');
}

// favorites using localStorage
const STORAGE_KEY = 'templeExplorer.favs';
function getFavorites() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.warn('Error reading localStorage', e);
        return [];
    }
}
function saveFavorites(arr) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
    renderFavorites();
}
function addFavorite(id) {
    const favs = getFavorites();
    // conditional branching: check if already exists
    if (favs.includes(id)) {
        alert('Already in favorites');
        return;
    }
    favs.push(id);
    saveFavorites(favs);
}
function removeFavorite(id) {
    const favs = getFavorites().filter(x => x !== id);
    saveFavorites(favs);
}
function renderFavorites() {
    const ul = $('#favorites-list');
    if (!ul) return;
    const favs = getFavorites();
    if (favs.length === 0) {
        ul.innerHTML = '<li>No favorites yet</li>';
        return;
    }
    ul.innerHTML = favs.map(id => {
        const t = temples.find(x => x.id === id);
        return `<li>${t ? t.name : id} <button data-id="${id}" class="remove-fav">Remove</button></li>`;
    }).join('');
}

// Event delegation for add/remove favorites
function onDocClick(e) {
    const add = e.target.closest('.fav-btn');
    if (add) {
        const id = add.getAttribute('data-id');
        addFavorite(id);
        return;
    }
    const rem = e.target.closest('.remove-fav');
    if (rem) {
        removeFavorite(rem.getAttribute('data-id'));
        return;
    }
}

// Form handling: simple validation and localStorage example
function handleSubscribe(e) {
    e.preventDefault();
    const name = $('#name').value.trim();
    const email = $('#email').value.trim();
    const msg = $('#form-message');
    if (name.length < 2 || !email.includes('@')) {
        msg.textContent = 'Please provide a valid name and email.';
        return;
    }
    const subs = JSON.parse(localStorage.getItem('templeExplorer.subs') || '[]');
    subs.push({ name, email, date: new Date().toISOString() });
    localStorage.setItem('templeExplorer.subs', JSON.stringify(subs));
    msg.textContent = `Thanks ${name}! You're subscribed.`;
    $('#subscribe-form').reset();
}

// Initialize on pages
function init() {
    // multiple functions used: buildTempleList, showFeatured, renderFavorites
    buildTempleList();
    showFeatured();
    renderFavorites();

    document.addEventListener('click', onDocClick);
    const randomBtn = document.getElementById('show-random');
    if (randomBtn) randomBtn.addEventListener('click', () => showFeatured(true));

    const form = document.getElementById('subscribe-form');
    if (form) form.addEventListener('submit', handleSubscribe);
}

document.addEventListener('DOMContentLoaded', init);

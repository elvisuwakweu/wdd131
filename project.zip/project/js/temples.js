// Temple data
const temples = [
    {
        name: "Tokyo Japan Temple",
        location: "Tokyo, Japan",
        dedicated: 1980,
        area: "Asia",
        image: "tokyo.jpg"
    },
    {
        name: "Aba Nigeria Temple",
        location: "Aba, Nigeria",
        dedicated: 2005,
        area: "Africa",
        image: "aba.jpg"
    },
    {
        name: "Accra Ghana Temple",
        location: "Accra, Ghana",
        dedicated: 2004,
        area: "Africa",
        image: "accra.jpg"
    },
    {
        name: "Salt Lake Temple",
        location: "Utah, USA",
        dedicated: 1893,
        area: "America",
        image: "salt-lake.jpg"
    },
    {
        name: "Rome Italy Temple",
        location: "Rome, Italy",
        dedicated: 2019,
        area: "Europe",
        image: "rome.jpg"
    },
    {
        name: "Lagos Nigeria Temple",
        location: "Lagos, Nigeria",
        dedicated: 2022,
        area: "Africa",
        image: "lagos.jpg"
    }
];

// Create temple cards
function createCard(t) {
    const card = document.createElement("article");
    card.innerHTML = `
    <h3>${t.name}</h3>
    <p><strong>Location:</strong> ${t.location}</p>
    <p><strong>Dedicated:</strong> ${t.dedicated}</p>
    <img src="images/${t.image}"
         loading="lazy"
         alt="${t.name}"
         onerror="this.src='images/placeholder.jpg'">
  `;
    return card;
}

// Display temples
const container = document.getElementById("temple-container");

if (container) {
    displayTemples(temples);

    function displayTemples(list) {
        container.innerHTML = "";
        list.forEach(t => container.appendChild(createCard(t)));
    }

    // Filtering
    const buttons = document.querySelectorAll(".filters button");

    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            const filter = btn.dataset.filter;

            let filtered = temples;

            if (filter === "old") {
                filtered = temples.filter(t => t.dedicated < 2000);
            } else if (filter === "new") {
                filtered = temples.filter(t => t.dedicated >= 2000);
            } else if (filter === "africa") {
                filtered = temples.filter(t => t.area === "Africa");
            } else if (filter === "asia") {
                filtered = temples.filter(t => t.area === "Asia");
            }

            displayTemples(filtered);
        });
    });
}

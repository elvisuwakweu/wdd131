// Mobile navigation
const ham = document.getElementById("hamburger");
const nav = document.getElementById("main-nav");

ham.addEventListener("click", () => {
    nav.style.display = nav.style.display === "flex" ? "none" : "flex";
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Contact form using template literals & localStorage
const form = document.getElementById("contactForm");
const output = document.getElementById("form-output");

if (form) {
    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const message = {
            name: form.name.value,
            email: form.email.value,
            message: form.message.value
        };

        localStorage.setItem("contactMessage", JSON.stringify(message));

        output.textContent = `Thanks, ${message.name}! Your message was saved.`;
    });
}
